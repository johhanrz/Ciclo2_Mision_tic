
package vehiculos;


public class Automovil extends Vehiculo{ // Crea la clase Automovil que hereda (extends) de la clase Vehiculo
    
    // Constructor de la clase a través de invocación de clase padre
    public Automovil(int pasajeros, double velocidad){
        super(pasajeros, velocidad);// invoca al constructor de la clase superior (Vehiculo)
    }

    // Override sobre escribe métodos de la clase padre u otra de la que se herede
    // en este caso se sobre escribe la clase pintar creada como abstracta en la clase padre (Vehiculo)
    @Override
    public void pintar(int posicion) {
        espacios(posicion+4);
        System.out.println("_____");
        espacios(posicion+1);
        System.out.println("__/__|__\\__");
        espacios(posicion);
        System.out.println("|_ _____ ___|");
        espacios(posicion);
        System.out.println("   O      O");
    }
}
