package vehiculos;


public abstract class Vehiculo { // Declara la clase ABSTRACTA vehiculo
    // Los atributos o métodos bajo el modificador protected son accesibles desde el paquete o subclases del mismo
    protected double velocidad;
    protected int pasajeros;

    // Crea constructor de la clase, un vehiculo con un número de pasajeros y velocidad
    public Vehiculo(int pasajeros,double velocidad) {
        this.velocidad = velocidad;
        this.pasajeros = pasajeros;
    }
    // Método de la clase retorna un valor entero, determina la posición del vehículo en un momento determinado
    public int posicion(int tiempo){
        return (int)(tiempo * velocidad);
    }
    // Método espacios, sin valor de retorno, imprime espacios en lanco para simular la posición del vehículo
    public void espacios(int espacios){
        for(int i=0;i<espacios;i++)
            System.out.print(' ');
    }
    // Método pintar sin valor de retorno con modificador como abstracto
    public abstract void pintar(int posicion);
}
