package vehiculos;
// La clase Platon hereda de la clase Carga

public class Platon extends Carga {

    // Constructor de la clase 
    //Crea un objeto que hereda de la clase Vehiculo, tiene cantidad de pasajeros, velocidad y capacidad de carga
    public Platon(int pasajeros, double velocidad, int peso) {    
        super(pasajeros, velocidad, peso); 
    }

    //método llevar, retorna un valor de tipo booleano
    public boolean llevar(int p) {
        boolean lolleva = super.llevar(p);
        if (lolleva) {
            String laCarga = this.carga.toString();
            String cargaInvertida = "";
            for (int i = laCarga.length() - 1; i >= 0; i--) {
                cargaInvertida += laCarga.charAt(i);
            }
            this.carga = cargaInvertida;
        }
        return lolleva;
    }
    // Llama a la clase heredada para pintar el vehiculo en la posición indicada
    // Modifica (Sobre escribe "override") el vehiculo a pintar.
    @Override
    public void pintar( int posicion ) {
	espacios(posicion+4);
	System.out.println("   __");
	espacios(posicion+1);
	String laCarga = this.carga.toString();
	int n = 5-laCarga.length();
	for( int i=0; i<n; i++ ) {
	    laCarga += '_';
	}
	System.out.println(laCarga+"|__\\___");
	espacios(posicion);
	System.out.println("|_   ___   __|");
	espacios(posicion);
	System.out.println("   O     O");
    }
}
