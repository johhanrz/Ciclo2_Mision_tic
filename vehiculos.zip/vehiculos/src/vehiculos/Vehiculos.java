/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vehiculos;

/**
 *
 * @author nvergara
 */
public class Vehiculos {

    public static void pausar() {
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();

        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //INSTANCIARÁ (Creará objetos) de cada clase (tipo de vehiculo) 
        
        Automovil automovil = new Automovil(5, 1);
        Deportivo deportivo = new Deportivo(5, 1.5);
        Platon camioneta = new Platon(3, 1.2, 4);
        camioneta.llevar(1234);
        Furgon furgon = new Furgon(3, 0.9, 4);
        furgon.llevar("AA");
        
        Vehiculo[] vehiculo=new Vehiculo[4];
        vehiculo[0]=automovil;
        vehiculo[1]=camioneta;
        vehiculo[2]=deportivo;
        vehiculo[3]=furgon;
        
        for(int i=0;i<50;i++){
            System.out.println();
            for(int j=0;j<vehiculo.length;j++){
                int pos = vehiculo[j].posicion(i);
                vehiculo[j].pintar(pos);

            }
            pausar();
            System.out.println("========================================================================");
        }
        
    }

}
